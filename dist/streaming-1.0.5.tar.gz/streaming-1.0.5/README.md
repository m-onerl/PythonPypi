# Build

```bash
python3 -m build
```

# Deploy

```bash
python3 -m twine upload --repository gitlab dist/* --verbose
```

# Login
``` bash
Użytkownik: __token__
Hasło: glpat-a5yB1rsydVjppBpm7Zwt
```